We crawled 10148 apps from Android markets and automaticly unpack them with Apktool. 
Third-party libraries are searched by traversaling every folder in the app and we 
obtain 352 libraries neglecting those with few usage. The dataset includes 10148 apps 
and 352 libraries. Each row of the app-lib matrix represents the libraries adopted 
by the current app. The adoption range is {0, 1}. If an app i adopts a library j, 
then the value is set 1 at the corresponding positions (i, j), and otherwise it is 0. 

The TPL dataset includes:

1. README.txt(1KB): Descriptions of the dataset.
2. applist.txt(231KB): Package names of apps.
3. liblist.txt(7KB): Names of third-party libraries.
4. app_lib.csv(6977KB): 10148*352 app-lib matrix in CSV format.

Download from http://www.inpluslab.com/files/TPL.zip