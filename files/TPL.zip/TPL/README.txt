We crawled 10148 apps from Android markets and unpack them one by one. 
Third-party libraries are searched by traversaling every folder in the 
app. We utilize the library list carried out by Viennot et al. with 
about 352 libraries. Based on this list, we drop those apps without 
adopting any of these libraries leaving 8695 apps. In the dataset, 
each row of the app-lib matrix represents the libraries adopted by 
the current app, where the value of 1 indicates that a library is 
adopted by an app and 0 vice versa.

The TPL dataset includes:

1. README.txt(1KB): Descriptions of the dataset.
2. applist.txt(238KB): Package names of apps. Format: | App ID | App Name |
3. liblist.txt(8KB): Names of third-party libraries. Format: | Lib ID | Lib Name |
4. app_lib.csv(356KB): 8695*352 app-lib matrix. Format: | App ID | Lib ID |

Download from http://www.inpluslab.com/files/TPL.zip